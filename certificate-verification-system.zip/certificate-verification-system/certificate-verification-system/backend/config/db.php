<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "certificate_system";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "✅ تم الاتصال بقاعدة البيانات بنجاح!";
} catch (PDOException $e) {
    die("❌ فشل الاتصال: " . $e->getMessage());
}
?>
