<?php
header("Content-Type: application/json; charset=UTF-8");
include_once("../config/db.php");

try {
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        echo json_encode(["success" => false, "message" => "Invalid request method"]);
        exit;
    }

    // قراءة البيانات القادمة من الجافاسكربت
    $data = json_decode(file_get_contents("php://input"), true);
    $id = isset($data["id"]) ? intval($data["id"]) : 0;
    $user_id = isset($data["user_id"]) ? intval($data["user_id"]) : 0;

    if ($id <= 0 || $user_id <= 0) {
        echo json_encode(["success" => false, "message" => "بيانات غير صالحة"]);
        exit;
    }

    // تحقق من أن الشهادة تخص المستخدم الحالي
    $stmt = $conn->prepare("SELECT file_path FROM certificates WHERE id = ? AND user_id = ?");
    $stmt->execute([$id, $user_id]);
    $cert = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$cert) {
        echo json_encode(["success" => false, "message" => "❌ لا يمكنك حذف شهادة لا تخصك"]);
        exit;
    }

    // حفظ مسار الملف قبل الحذف
    $filePath = "../../uploads/certificates/" . $cert["file_path"];

    // حذف السجل من قاعدة البيانات
    $delete = $conn->prepare("DELETE FROM certificates WHERE id = ? AND user_id = ?");
    $delete->execute([$id, $user_id]);

    if ($delete->rowCount() > 0) {
        // حذف الملف فعليًا من السيرفر إذا كان موجودًا
        if (file_exists($filePath)) {
            unlink($filePath);
        }
        echo json_encode(["success" => true, "message" => "✅ تم حذف الشهادة والملف بنجاح"]);
    } else {
        echo json_encode(["success" => false, "message" => "⚠️ لم يتم العثور على الشهادة"]);
    }
} catch (Throwable $e) {
    echo json_encode(["success" => false, "message" => "حدث خطأ داخلي: " . $e->getMessage()]);
}
?>
