<?php
header("Content-Type: application/json; charset=UTF-8");
include_once("../config/db.php");

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(["success" => false, "message" => "Invalid request method"]);
        exit;
    }

    // استقبال البيانات
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $file = $_FILES['certificate'] ?? null;

    // التحقق من القيم
    if ($name === '' || $email === '' || !$file) {
        echo json_encode(["success" => false, "message" => "يرجى إدخال جميع البيانات واختيار ملف الشهادة"]);
        exit;
    }

    // أنواع الملفات المسموحة
    $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) {
        echo json_encode(["success" => false, "message" => "صيغة الملف غير مدعومة"]);
        exit;
    }

    // مجلد الرفع
    $uploadDir = "../uploads/certificates/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $newName = uniqid("cert_") . "." . $ext;
    $targetPath = $uploadDir . $newName;

    // رفع الملف
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        echo json_encode(["success" => false, "message" => "فشل في رفع الملف"]);
        exit;
    }

    // إدخال البيانات في قاعدة البيانات
    $stmt = $conn->prepare("INSERT INTO certificates (user_id, full_name, email, file_path) VALUES (?, ?, ?, ?)");
    $userId = 1; // لاحقاً نربطها بالمستخدم الحالي

    if ($stmt->execute([$userId, $name, $email, $newName])) {
        echo json_encode(["success" => true, "message" => "تم رفع الشهادة بنجاح"]);
    } else {
        echo json_encode(["success" => false, "message" => "حدث خطأ أثناء حفظ البيانات"]);
    }

} catch (Throwable $e) {
    echo json_encode(["success" => false, "message" => "حدث خطأ داخلي: " . $e->getMessage()]);
}
?>
