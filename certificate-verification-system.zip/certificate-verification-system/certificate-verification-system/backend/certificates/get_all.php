<?php
header("Content-Type: application/json; charset=UTF-8");
include_once("../config/db.php");

try {
    // مؤقتًا نعرض جميع الشهادات من الجدول بدون شرط user_id
    $stmt = $conn->prepare("SELECT id, user_id, full_name, email, file_path, status, created_at FROM certificates ORDER BY id DESC");
    $stmt->execute();
    $certificates = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(["success" => true, "data" => $certificates]);
} catch (Throwable $e) {
    echo json_encode(["success" => false, "message" => "خطأ أثناء جلب البيانات: " . $e->getMessage()]);
}
?>
