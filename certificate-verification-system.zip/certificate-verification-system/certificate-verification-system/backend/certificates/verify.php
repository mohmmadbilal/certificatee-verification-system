<?php
require_once("../config/db.php");
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["certId"])) {
        $certId = $_POST["certId"];

        try {
            $stmt = $conn->prepare("SELECT * FROM certificates WHERE id = ?");
            $stmt->execute([$certId]);
            $certificate = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($certificate) {
                echo json_encode([
                    "status" => "found",
                    "data" => [
                        "name" => $certificate["full_name"],
                        "issue_date" => $certificate["created_at"],
                        "certificate_title" => "شهادة حضور/إتمام"
                    ]
                ]);
            } else {
                echo json_encode([
                    "status" => "error",
                    "message" => "الشهادة غير موجودة"
                ]);
            }
        } catch (PDOException $e) {
            echo json_encode([
                "status" => "error",
                "message" => "خطأ في قاعدة البيانات: " . $e->getMessage()
            ]);
        }
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "لم يتم إرسال رقم الشهادة"
        ]);
    }
}
