<?php
header("Content-Type: application/json; charset=UTF-8");
include_once("../config/db.php");

// التحقق من أن الطلب هو POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
    exit;
}

// استقبال البيانات من النموذج
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');
$confirm = trim($_POST['confirm'] ?? '');

// التحقق من الحقول الفارغة
if ($name === '' || $email === '' || $password === '' || $confirm === '') {
    echo json_encode(["success" => false, "message" => "يرجى تعبئة جميع الحقول"]);
    exit;
}

// التحقق من تطابق كلمتي المرور
if ($password !== $confirm) {
    echo json_encode(["success" => false, "message" => "كلمتا المرور غير متطابقتين"]);
    exit;
}

// التحقق إذا البريد الإلكتروني مسجل مسبقًا
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->rowCount() > 0) {
    echo json_encode(["success" => false, "message" => "هذا البريد مسجل مسبقًا"]);
    exit;
}

// تشفير كلمة المرور
$hashed = password_hash($password, PASSWORD_DEFAULT);

// إدخال المستخدم الجديد
$stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
if ($stmt->execute([$name, $email, $hashed])) {
    echo json_encode(["success" => true, "message" => "تم إنشاء الحساب بنجاح"]);
} else {
    echo json_encode(["success" => false, "message" => "حدث خطأ أثناء إنشاء الحساب"]);
}
?>
