<?php
header("Content-Type: application/json; charset=UTF-8");
include_once("../config/db.php");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
    exit;
}

$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($email === '' || $password === '') {
    echo json_encode(["success" => false, "message" => "يرجى إدخال البريد وكلمة المرور"]);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['password'])) {
    // نجاح الدخول
    echo json_encode([
        "success" => true,
        "message" => "تم تسجيل الدخول بنجاح",
        "user" => [
            "id" => $user['id'],
            "name" => $user['name'],
            "email" => $user['email']
        ]
    ]);
} else {
    echo json_encode(["success" => false, "message" => "البريد أو كلمة المرور غير صحيحة"]);
}
?>
