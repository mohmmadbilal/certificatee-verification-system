window.addEventListener('load', async () => {
    if (typeof window.ethereum !== 'undefined') {
        const web3 = new Web3(window.ethereum);

        try {
            await window.ethereum.enable();
            console.log("✅ تم الاتصال بـ MetaMask");

            const chainId = await web3.eth.getChainId();
            console.log("🔗 الشبكة الحالية:", chainId);

            const contractAddress = "0xf8e81D47203A594245E36C48e151709F0C19fBe8";

            const abi = [
                {
                    "inputs": [
                        { "internalType": "uint256", "name": "certId", "type": "uint256" },
                        { "internalType": "string", "name": "name", "type": "string" },
                        { "internalType": "string", "name": "issueDate", "type": "string" },
                        { "internalType": "string", "name": "certificateTitle", "type": "string" }
                    ],
                    "name": "addCertificate",
                    "outputs": [],
                    "stateMutability": "nonpayable",
                    "type": "function"
                },
                {
                    "inputs": [{ "internalType": "uint256", "name": "certId", "type": "uint256" }],
                    "name": "verifyCertificate",
                    "outputs": [
                        { "internalType": "string", "name": "name", "type": "string" },
                        { "internalType": "string", "name": "issueDate", "type": "string" },
                        { "internalType": "string", "name": "certificateTitle", "type": "string" }
                    ],
                    "stateMutability": "view",
                    "type": "function"
                }
            ];

            const contract = new web3.eth.Contract(abi, contractAddress);

            document.getElementById("verifyForm").addEventListener("submit", async function (e) {
                e.preventDefault();

                const certId = document.getElementById("certId").value;
                const resultDiv = document.getElementById("result");
                resultDiv.innerHTML = `<div class="text-center text-muted">🔄 جاري التحقق من العقد الذكي على البلوك تشين...</div>`;

                try {
                    const result = await contract.methods.verifyCertificate(certId).call();

                    if (result.name && result.name !== "") {
                        resultDiv.innerHTML = `
                        <div class="alert alert-success">
                            ✅ الشهادة موجودة على شبكة البلوك تشين<br>
                            👤 الاسم: ${result.name}<br>
                            🗓️ تاريخ الإصدار: ${result.issueDate}<br>
                            🏆 عنوان الشهادة: ${result.certificateTitle}
                            <br><small class="text-muted d-block mt-2">📦 تم التحقق باستخدام <strong>عقد ذكي Smart Contract</strong> على شبكة Ethereum</small>
                        </div>
                        `;
                    } else {
                        resultDiv.innerHTML = `<div class="alert alert-danger">❌ لا توجد شهادة بهذا الرقم على البلوك تشين</div>`;
                    }

                } catch (err) {
                    resultDiv.innerHTML = `<div class="alert alert-danger">⚠️ فشل في الاتصال بالعقد الذكي: ${err.message}</div>`;
                    console.error(err);
                }
            });

        } catch (error) {
            alert("❌ لم يتم السماح بالاتصال بـ MetaMask");
            console.error("MetaMask connection error:", error);
        }

    } else {
        alert("⚠️ يرجى تثبيت MetaMask أولاً للتفاعل مع البلوك تشين");
    }
});
