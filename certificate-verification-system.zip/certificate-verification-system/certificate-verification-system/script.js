document.addEventListener("DOMContentLoaded", function () {
    console.log("✅ script.js loaded successfully");

   
    const registerForm = document.getElementById("registerForm");
    if (registerForm) {
        registerForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const name = document.getElementById("regName").value;
            const email = document.getElementById("regEmail").value;
            const password = document.getElementById("regPassword").value;
            const confirm = document.getElementById("regConfirmPassword").value;
            const message = document.getElementById("registerMessage");

            const formData = new FormData();
            formData.append("name", name);
            formData.append("email", email);
            formData.append("password", password);
            formData.append("confirm", confirm);

            message.innerHTML = '<p class="text-info">جاري إنشاء الحساب...</p>';

            try {
                const response = await fetch("backend/auth/register.php", {
                    method: "POST",
                    body: formData,
                });
                const result = await response.json();

                if (result.success) {
                    message.innerHTML = `<p class="text-success">${result.message}</p>`;
                    setTimeout(() => (window.location.href = "login.html"), 1500);
                } else {
                    message.innerHTML = `<p class="text-danger">${result.message}</p>`;
                }
            } catch (error) {
                console.error(error);
                message.innerHTML = '<p class="text-danger">حدث خطأ أثناء الاتصال بالسيرفر</p>';
            }
        });
    }

 

    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const email = document.getElementById("loginEmail").value;
            const password = document.getElementById("loginPassword").value;
            const message = document.getElementById("loginMessage");

            message.innerHTML = '<p class="text-info">جاري التحقق...</p>';

            const formData = new FormData();
            formData.append("email", email);
            formData.append("password", password);

            try {
                const response = await fetch("backend/auth/login.php", {
                    method: "POST",
                    body: formData,
                });
                const result = await response.json();

                if (result.success) {
                    message.innerHTML = `<p class="text-success">${result.message}</p>`;
                    localStorage.setItem("user", JSON.stringify(result.user));
                    localStorage.setItem("loggedIn", "true");
                    setTimeout(() => (window.location.href = "dashboard.html"), 1500);
                } else {
                    message.innerHTML = `<p class="text-danger">${result.message}</p>`;
                }
            } catch (error) {
                console.error(error);
                message.innerHTML = '<p class="text-danger">حدث خطأ أثناء الاتصال بالسيرفر</p>';
            }
        });
    }

    const uploadForm = document.getElementById("uploadForm");
    if (uploadForm) {
        uploadForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const message = document.getElementById("message");
            const formData = new FormData(uploadForm);

            message.innerHTML = '<p class="text-info">جاري رفع الشهادة...</p>';

            try {
                const response = await fetch("backend/certificates/upload.php", {
                    method: "POST",
                    body: formData,
                });

                const result = await response.json();
                if (result.success) {
                    message.innerHTML = `<p class="text-success">${result.message}</p>`;
                    uploadForm.reset();
                } else {
                    message.innerHTML = `<p class="text-danger">${result.message}</p>`;
                }
            } catch (error) {
                console.error(error);
                message.innerHTML = '<p class="text-danger">حدث خطأ أثناء الاتصال بالسيرفر</p>';
            }
        });
    }


    if (window.location.pathname.includes("dashboard.html")) {
        const certTableBody = document.querySelector("#certsTable");
        if (certTableBody) {
            certTableBody.innerHTML = "<tr><td colspan='7'>جاري تحميل البيانات...</td></tr>";

            async function loadCertificates() {
                try {
                    const res = await fetch("backend/certificates/get_all.php");
                    const result = await res.json();

                    if (result.success && result.data.length > 0) {
                        certTableBody.innerHTML = "";

                        result.data.forEach((cert) => {
                            const downloadPath = `backend/uploads/certificates/${cert.file_path}`;
                            const row = `
                                <tr>
                                    <td>${cert.id}</td>
                                    <td>${cert.full_name}</td>
                                    <td>${cert.email}</td>
                                    <td>
                                        <span class="badge bg-${
                                            cert.status === "verified"
                                                ? "success"
                                                : cert.status === "pending"
                                                ? "warning"
                                                : "danger"
                                        }">${cert.status}</span>
                                    </td>
                                    <td>${cert.created_at}</td>
                                    <td>
                                        <a href="${downloadPath}" target="_blank" class="btn btn-sm btn-outline-primary">
                                            تحميل <i class="fas fa-download"></i>
                                        </a>
                                        <button class="btn btn-sm btn-outline-danger ms-1 delete-cert" data-id="${cert.id}">
                                            حذف <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            `;
                            certTableBody.insertAdjacentHTML("beforeend", row);
                        });

                        document.querySelectorAll(".delete-cert").forEach((btn) => {
                            btn.addEventListener("click", async () => {
                                const id = btn.getAttribute("data-id");
                                const user = JSON.parse(localStorage.getItem("user") || "{}");

                                if (!user.id) {
                                    alert("حدث خطأ: لم يتم تحديد المستخدم الحالي.");
                                    return;
                                }

                                if (confirm("هل أنت متأكد أنك تريد حذف هذه الشهادة؟")) {
                                    try {
                                        const delRes = await fetch("backend/certificates/delete.php", {
                                            method: "POST",
                                            headers: { "Content-Type": "application/json" },
                                            body: JSON.stringify({ id, user_id: user.id }),
                                        });

                                        const delResult = await delRes.json();
                                        alert(delResult.message);
                                        loadCertificates();
                                    } catch (err) {
                                        alert("حدث خطأ أثناء الحذف، حاول مجددًا.");
                                        console.error(err);
                                    }
                                }
                            });
                        });
                    } else {
                        certTableBody.innerHTML = "<tr><td colspan='7'>لا توجد شهادات بعد.</td></tr>";
                    }
                } catch (error) {
                    console.error(error);
                    certTableBody.innerHTML = "<tr><td colspan='7' class='text-danger'>حدث خطأ أثناء تحميل البيانات</td></tr>";
                }
            }

            loadCertificates();
        }
    }


    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const name = document.getElementById("contactName").value;
            const email = document.getElementById("contactEmail").value;
            const subject = document.getElementById("contactSubject").value;
            const messageText = document.getElementById("contactMessage").value;
            const feedback = document.getElementById("contactMsg");

            if (!name || !email || !subject || !messageText) {
                feedback.innerHTML = '<p class="text-danger">يرجى ملء جميع الحقول.</p>';
                return;
            }

            feedback.innerHTML = '<p class="text-info">جاري إرسال الرسالة... يرجى الانتظار.</p>';
            setTimeout(() => {
                feedback.innerHTML = '<p class="text-success">تم إرسال رسالتك بنجاح! سنرد عليك قريبًا.</p>';
                contactForm.reset();
            }, 2000);
        });
    }

   
    checkAuth();

    
    const verifyForm = document.getElementById("verifyForm");
    if (verifyForm) {
        verifyForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const certId = document.getElementById("certId").value;
            const formData = new FormData();
            formData.append("certId", certId);

            const res = await fetch("backend/certificates/verify.php", {
                method: "POST",
                body: formData
            });

            const text = await res.text();
            console.log("📦 Response Text:", text);

            let data;
            try {
                data = JSON.parse(text);
                console.log("✅ JSON Parsed:", data);
            } catch (e) {
                console.error("❌ Failed to parse JSON:", e);
            }

            const resultDiv = document.getElementById("result");

            if (data && data.status === "found") {
                resultDiv.innerHTML = `
                    <p><strong>اسم المستلم:</strong> ${data.data.name}</p>
                    <p><strong>تاريخ الإصدار:</strong> ${data.data.issue_date}</p>
                    <p><strong>اسم الشهادة:</strong> ${data.data.certificate_title}</p>
                `;
            } else {
                resultDiv.innerHTML = `<p style="color:red;">${data?.message || 'تعذر في الحصول على البيانات'}</p>`;
            }
        });
    }
});


function checkAuth() {
    const loggedIn = localStorage.getItem("loggedIn") === "true";
    const loginLink = document.getElementById("loginLink");
    const logoutLink = document.getElementById("logoutLink");

    if (loginLink && logoutLink) {
        if (loggedIn) {
            loginLink.classList.add("d-none");
            logoutLink.classList.remove("d-none");
        } else {
            loginLink.classList.remove("d-none");
            logoutLink.classList.add("d-none");
        }
    }

    if (
        window.location.pathname.includes("dashboard.html") &&
        !loggedIn
    ) {
        window.location.href = "login.html";
    }
}

const contractAddress = "0xf8e81D47203A594245E36C48e151709F0C19fBe8"; 
const contractABI = [
   {
                    "inputs": [
                        { "internalType": "uint256", "name": "certId", "type": "uint256" },
                        { "internalType": "string", "name": "name", "type": "string" },
                        { "internalType": "string", "name": "issueDate", "type": "string" },
                        { "internalType": "string", "name": "certificateTitle", "type": "string" }
                    ],
                    "name": "addCertificate",
                    "outputs": [],
                    "stateMutability": "nonpayable",
                    "type": "function"
                },
                {
                    "inputs": [{ "internalType": "uint256", "name": "certId", "type": "uint256" }],
                    "name": "verifyCertificate",
                    "outputs": [
                        { "internalType": "string", "name": "name", "type": "string" },
                        { "internalType": "string", "name": "issueDate", "type": "string" },
                        { "internalType": "string", "name": "certificateTitle", "type": "string" }
                    ],
                    "stateMutability": "view",
                    "type": "function"
                }
];


function logout() {
    localStorage.removeItem("loggedIn");
    localStorage.removeItem("user");
    window.location.href = "index.html";
}
